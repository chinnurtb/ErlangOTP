#!/bin/sh
./hbase-0.20.3/bin/stop-hbase.sh

