#!/bin/sh
./hbase-0.20.3/bin/start-hbase.sh

